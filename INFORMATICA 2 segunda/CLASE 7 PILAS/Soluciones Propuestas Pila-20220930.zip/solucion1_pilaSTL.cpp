/* Crear un programa en la cual el usuario cargue una serie de valores en una 
pila. Luego se pide:
- mostrar en pantalla el los elementos de la pila
- borrar un elemento de la pila
- agregar un elemento que no este en la pila
*/

#include <iostream>
#include <stack>

using namespace std;

void mostrarPila(stack<double>);
stack<double> borrarElemento(stack<double>);
stack<double> agregarElemento(stack<double>);
bool buscarElemento(stack<double>, double);

int main(int argc, char *argv[]) {
	
	stack<double> lapila; 
	double num=0;
	
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lapila.push(num);
	}
	while (num != 0);
	
	mostrarPila(lapila);
	lapila=borrarElemento(lapila);
	mostrarPila(lapila);
	lapila=agregarElemento(lapila);
	mostrarPila(lapila);
	return 0;
}


void mostrarPila(stack<double> lapila){
	stack<double> aux_pila; 
	cout << "\nLos elementos de la pila son:\t";
	while(!lapila.empty())
	{
		cout << lapila.top() <<" - ";
		aux_pila.push(lapila.top()); 
		lapila.pop();
	}
	lapila=aux_pila;
}
	
stack<double> borrarElemento(stack<double> lapila){
	double num_borrar=0;
	stack<double> aux_pila;
	cout << "\nIngrese el elemento a borrar: ";
	cin>>num_borrar;
	while(!lapila.empty())
	{
		if(lapila.top()!=num_borrar){
			aux_pila.push(lapila.top()); 
		}
		lapila.pop();
	}
	lapila=aux_pila;
	return lapila;
}
		
bool buscarElemento(stack<double> lapila, double num_buscar){
	stack<double> aux_pila;
	bool bandera_buscado=false;
	while(!lapila.empty())
	{
		if(lapila.top()==num_buscar){
			bandera_buscado=true;
		}
		aux_pila.push(lapila.top()); 
		lapila.pop();
	}
	lapila=aux_pila;	
	return bandera_buscado;
}
			
stack<double> agregarElemento(stack<double> lapila){
	double num_agregar=0;
	stack<double> aux_pila;
	bool bandera=false;
	do{
		cout << "\nIngrese el elemento a agregar: ";
		cin>>num_agregar;
		bandera=buscarElemento(lapila, num_agregar);
		if(bandera==false){
			lapila.push(num_agregar);
		}else{
			cout << "\nExiste este valor.";
		}
	}while(bandera==true);
	return lapila;
}				
