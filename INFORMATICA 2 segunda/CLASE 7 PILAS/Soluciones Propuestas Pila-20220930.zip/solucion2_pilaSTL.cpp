/* Elaborar un sistema de stock, en la cual posee 
una pila de productos con los siguientes atributos: 
codigo, nombre, cantidad, precio lista
Desarrollar las siguientes funciones:
a. Mostrar el stock. (pila de productos)
b. Descontar stock.
c. Reponer stock.

*/

#include <iostream>
#include "Producto.h"
#include <stack>

using namespace std;

void mostrar(stack<Producto>);
stack <Producto> descontar(stack<Producto>);
stack <Producto> reponer(stack<Producto>);

int main(int argc, char *argv[]) {
	Producto p;
	stack<Producto> pilaProducto;
	
	p.setCodigo(1);
	p.setNombre("Yerba");
	p.setCantidad(10);
	p.setPrecio(50);
	pilaProducto.push(p);
	
	p.setCodigo(2);
	p.setNombre("Azucar");
	p.setCantidad(15);
	p.setPrecio(30.5);
	pilaProducto.push(p);
	
	p.setCodigo(3);
	p.setNombre("Harina");
	p.setCantidad(3);
	p.setPrecio(35);
	pilaProducto.push(p);
	
	char op = ' ';
	do{
		cout<<"********************* MENU DE OPCIONES *******************"<<endl;
		cout<<"a. Mostrar stock."<<endl;
		cout<<"b. Descontar stock."<<endl;
		cout<<"c. Reponer stock."<<endl;
		cout<<"\nOpcion: ";
		cin>>op;
		switch(op){
		case 'a': 
		case 'A': 
			mostrar(pilaProducto);
			break;
		case 'b': 
		case 'B': 
			pilaProducto=descontar(pilaProducto);
			break;
		case 'c': 
		case 'C': 
			pilaProducto=reponer(pilaProducto);
			break;
		default: 
			cout<<"Ingrese una opcion valida. ";
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	}while(op=='s' || op=='S');
	return 0;
}


void mostrar(stack <Producto> pilaProducto){
	Producto p;
	stack<Producto> aux_pila; 
	cout<<"Cod\tNom\tCant\tPre"<<endl;
	while(!pilaProducto.empty())
	{
		p=pilaProducto.top();
		cout<<p.getCodigo()<<"\t"<<p.getNombre()<<"\t"<<p.getCantidad()<<"\t"<<p.getPrecio()<<endl;
		aux_pila.push(pilaProducto.top()); 
		pilaProducto.pop();
	}
	pilaProducto=aux_pila;	
}
	
stack <Producto> descontar(stack <Producto> pilaProducto){
	Producto p;
	stack<Producto> aux_pila; 
	int cod=0,desc=0;
	cout<<"Ingrese el codigo del producto a descontar: ";
	cin>>cod;
	while(!pilaProducto.empty())
	{
		p=pilaProducto.top();
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a descontar: ";
			cin>>desc;
			while(desc>p.getCantidad()){
				cout<<"Ingrese una cantidad menor o igual a "<<p.getCantidad()<<": ";
				cin>>desc;
			}
			p.setCantidad(p.getCantidad()-desc);
		}
		aux_pila.push(p); 
		pilaProducto.pop();
	}
	return aux_pila;
}
		
stack <Producto> reponer (stack <Producto> pilaProducto){
	Producto p;
	stack<Producto> aux_pila; 
	int cod=0,rep=0;
	cout<<"Ingrese el codigo del producto a reponer: ";
	cin>>cod;
	while(!pilaProducto.empty())
	{
		p=pilaProducto.top();
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a reponer: ";
			cin>>rep;
			while(rep<=0){
				cout<<"Ingrese una cantidad mayor a cero: ";
				cin>>rep;
			}
			p.setCantidad(p.getCantidad()+rep);
		}
		aux_pila.push(p); 
		pilaProducto.pop();
	}
	return aux_pila;
}
