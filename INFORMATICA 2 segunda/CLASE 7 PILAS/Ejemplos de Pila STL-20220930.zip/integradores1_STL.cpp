/*Crear un programa en la cual el usuario cargue una serie de valores en una 
lista. Luego copie los valores pares a una cola y los impares a una pila. Finalmente
mostrar la lista completa, cola de pares y pila de impares.
*/

#include <iostream>
#include <stack>
#include <queue>
#include <list>

using namespace std;

int main(int argc, char *argv[]) {
	
	list<int> lalista;
	queue<int> lacola;
	stack<int> lapila;
	int num=0;
	
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lalista.push_back(num);
	}
	while (num != 0);
	
	cout << "\nLos elementos de la lista son: ";
	while(!lalista.empty())
	{
		cout << lalista.front() <<" - ";
		if(lalista.front()%2==0){
			lacola.push(lalista.front());
		}else{
			lapila.push(lalista.front());
		}
		lalista.pop_front();
	}
	cout << "\nLos elementos pares de la cola son: ";
	while(!lacola.empty())
	{
		cout << lacola.front()<<" - ";
		lacola.pop();
	}
	cout << "\nLos elementos impares de la pila son: ";
	while(!lapila.empty())
	{
		cout << lapila.top()<<" - ";
		lapila.pop();
	}
	
	
	return 0;
}

