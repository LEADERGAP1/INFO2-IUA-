/* Crear un programa en la cual el usuario cargue una serie de valores en una 
pila. Luego se pide:
- calcular el promedio de los valores
- mostrar en pantalla el los elementos de la cola
*/

#include <iostream>
#include <stack>
using namespace std;

double calcularPromedioPila(stack<double>);
void mostrarPila(stack<double>);

int main(int argc, char *argv[]) {
	
	stack<double> lapila; 	//creamos una pila con un tipo
	double num=0;
	
	//apilamos valores a la pila con la funcion push()
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lapila.push(num);
	}
	while (num != 0);
	
	cout << "El promedio de los elementos de la pila es: " << calcularPromedioPila(lapila) << endl;
	mostrarPila(lapila);
	return 0;
}

double calcularPromedioPila(stack<double> lapila){
	stack<double> aux_pila; //creamos una pila auxiliar para no perder los valores
	double suma=0, prom=0;
	while(!lapila.empty())
	{
		suma=suma+lapila.top();
		aux_pila.push(lapila.top()); //para no perder los valores los pasamos a una pila auxiliar
		lapila.pop(); //borra el elemento de la pila original
	}
	lapila=aux_pila;//pasa los valores de la pila auxiliar a la pila original
	prom=suma/lapila.size();
	return prom;
}
	
	
void mostrarPila(stack<double> lapila){
	stack<double> aux_pila; //creamos una pila auxiliar para no perder los valores
	cout << "\nLos elementos de la pila son: ";
	while(!lapila.empty())
	{
		cout << lapila.top() <<" - ";
		aux_pila.push(lapila.top()); //para no perder los valores los pasamos a una pila auxiliar
		lapila.pop(); //borra el elemento de la pila original
	}
	lapila=aux_pila;//pasa los valores de la pila auxiliar a la pila original
}
		
