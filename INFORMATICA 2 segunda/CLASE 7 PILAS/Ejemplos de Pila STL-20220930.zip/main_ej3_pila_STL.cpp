/* Elaborar un sistema para un hostel, en la cual posee 
una pila de habitaciones con los siguientes atributos: 
int numeroHabitacion, int cantCamas, int estadoHabitacion. 
Este ultimo puede estar ocupada (1) o desocupada (0). 
Desarrollar las siguientes funciones:
a. Mostrar las habitaciones de la lista. 
b. Reservar habitacion, es decir cambiar el estado de 
desocupado a ocupado.

Num_hab		cant_camas		estado
1			3				1
2			2				0
3			1				0

*/

#include <iostream>
#include <stack>

using namespace std;

struct habitacion
{
	int numeroHabitacion;
	int cantCamas;
	int estadoHabitacion;
};

void mostrar(stack<habitacion> );
stack<habitacion> reservar(stack<habitacion>);

int main(int argc, char *argv[]) {
	
	struct habitacion h; 
	stack<habitacion> pilaHabitaciones; 
	
	h.numeroHabitacion=1;
	h.cantCamas=3;
	h.estadoHabitacion=1;
	pilaHabitaciones.push(h);
	
	h.numeroHabitacion=2;
	h.cantCamas=2;
	h.estadoHabitacion=0;
	pilaHabitaciones.push(h);
	
	h.numeroHabitacion=3;
	h.cantCamas=1;
	h.estadoHabitacion=0;
	pilaHabitaciones.push(h);
	
	mostrar(pilaHabitaciones);
	pilaHabitaciones=reservar(pilaHabitaciones);
	mostrar(pilaHabitaciones);
	
	return 0;
}

void mostrar(stack<habitacion> pilaHabitaciones){
	stack<habitacion> aux_pila; 
	struct habitacion h;
	cout<<"\nLista de habitaciones "<<endl;
	cout<<"Num. Hab.\tCant. Cam.\tEstado"<<endl;
	while(!pilaHabitaciones.empty())
	{
		h=pilaHabitaciones.top();
		cout<<h.numeroHabitacion<<"\t\t"<<h.cantCamas<<"\t\t"<<h.estadoHabitacion<<endl;
		aux_pila.push(pilaHabitaciones.top()); 
		pilaHabitaciones.pop();
	}
	pilaHabitaciones=aux_pila;	
}
	
stack<habitacion> reservar(stack<habitacion> pilaHabitaciones){
	stack<habitacion> aux_pila; 
	struct habitacion h;
	cout<<"\nLista de habitaciones disponibles "<<endl;
	while(!pilaHabitaciones.empty()){
		h=pilaHabitaciones.top();
		if(h.estadoHabitacion==0){
			cout<<h.numeroHabitacion<<"\t\t"<<h.cantCamas<<"\t\t"<<h.estadoHabitacion<<endl;
		}
		aux_pila.push(pilaHabitaciones.top()); 
		pilaHabitaciones.pop();
	}
		
	int num_hab;
	cout<<"\nSeleccionar un numero de habitacion: ";
	cin>>num_hab;
	while(!aux_pila.empty()){
		h=aux_pila.top();
		if(h.numeroHabitacion==num_hab){
			h.estadoHabitacion=1;
		}
		pilaHabitaciones.push(h); 
		aux_pila.pop();
	}
	return pilaHabitaciones;
}
