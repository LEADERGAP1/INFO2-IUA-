#include <iostream>
#include <stack>

using namespace std;

int main(int argc, char *argv[]) {
	
	stack<double> lapila; 	//creamos una pila con un tipo
	double num=0;
	
	//apilamos valores a la pila con la funcion push()
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lapila.push(num);
	}
	while (num != 0);
	
	cout << "\nCantidad de elementos de la pila: "<<lapila.size()<<endl;
	
	cout << "\nEl ultimo elemento de la pila es: "<<lapila.top()<<endl;	
	
	cout << "\nLos elementos de la pila son: ";
	
	//recorremos la pila hasta que este vacia, con la funcion empty()
	while(!lapila.empty())
	{
		num = lapila.top(); //trae el ultimo elemento de la pila
		cout << num <<" - ";
		lapila.pop(); //borra el elemento de la pila
	}
	
	return 0;
}

