#include <iostream>
#include <stdlib.h>
#include <ctime>
using namespace std;
/*2. Ampliar el programa del ejercicio anterior, para que almacene datos de hasta 3 canciones en un vector de estructura. Luego crear un men� que permita las opciones (cada una es una funci�n): 
	
	a. agregar una nueva canci�n
	
	b. mostrar todas las canciones
	
	c. buscar una canci�n por titulo*/

//Nota: Para comparar dos string utilizar la funci�n cadena1.compare(cadena2) de la librer�a string. Por ejemplo: if(cadena1.compare(cadena2)==0) si es 0 (cero) significa que son iguales los string.

struct cancion
{
	string titulo;
	string artista;
	int duracion;
	int tamanio_archivo;
};
int main(int argc, char *argv[]) {
	struct cancion c[3];
	string buscar_cancion;
	char opcion=' ';
	int i=0;
do{
	printf("a_ingrese cancion con sus respectivos datos\n");
	printf("b_mostrar lista\n");
	printf("c_buscar artista\n");
	scanf(" %c",&opcion);
	switch(opcion)
	{
	case 'a':
		for(int i=0;i<3;i++){
			printf("Nombre del artista:\n");
			scanf("%s", &c[i].artista);
			printf("\nNombre de la cancion:\n");
			scanf("%s", &c[i].titulo);
			printf("\nDuracion de la cancion:\n");
			scanf("%d", &c[i].duracion);
			printf("\nTama�o del archivo:\n");
			scanf("%d", &c[i].tamanio_archivo);
		}
		break;
	case 'b':	
		for(int i=0;i<3;i++){
			printf("\nDatos de la cancion:\n");
			printf("Artista: %s",c[i].artista);
			printf("\nTitulo: %s",c[i].titulo);
			printf("\nDuracion: %d",c[i].duracion);
			printf("\nTamanio del archivo: %d\n",c[i].tamanio_archivo);
		}
		break;
	case 'c':
		printf("que cancion decea buscar\n");
		scanf("%s",buscar_cancion);
		if(buscar_cancion.compare(c[i].titulo)==0)
		{
			printf("Artista: %s",c[i].artista);
			printf("\nTitulo: %s",c[i].titulo);
			printf("\nDuracion: %d",c[i].duracion);
			printf("\nTamanio del archivo: %d\n",c[i].tamanio_archivo);
		}else
		{
			printf("no se encontro cancion\n");
		}
		break;
	}
	printf("continuar?\n");
	scanf(" %c",&opcion);
	
}while(opcion=='s');
	

	return 0;
}
