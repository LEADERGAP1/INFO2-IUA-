/* Eje anterior
4. Crear una estructura llamada persona con sus atributos nombre, apellido, 
fecha de nacimiento, direcci�n y tel�fono. Tanto la direcci�n como la 
fecha de nacimiento son otras estructuras (estructura anidada). Cargue con 
datos y luego mu�strelos.

5. Tomar el ejercicio anterior y modificarlo para que se cree un vector de 
estructuras de tama�o 5. Cargar valores y mostrar. 
*/

#include <iostream>
using namespace std;

//definimos todas las estructuras a tener en cuenta ..
struct fecha_nacimiento
{
	int dia;
	int mes;
	int anio;
};

struct direccion
{
	string  calle;
	int  numero;
};

struct persona
{
	string nombre;
	string apellido;
	struct fecha_nacimiento f;  //se declara la variable f 
	struct direccion d;         //se declara la variable d 
	long long telefono;         
};


int main(int argc, char *argv[]) {
	
	struct persona p[2];        //CREAMOS UN ARREGLO DE ESTRUCTURAS LLAMADO p,SERA DOS ESTRUCTURAS,y su tipo sera struct persona
	int i=0;
	
	//HACEMOS LA CARGA DE DATOS DE LA ESTRUCTURA ANIDADA ,struct persona
	cout<<"Ingrese los datos de las personas: "<<endl;
	for(i=0; i<2; i++){
		cout<<"\nNombre: ";
		cin>>p[i].nombre;
		cout<<"Apellido: ";
		cin>>p[i].apellido;
		//--------------------
		cout<<"Dia de nacimiento: ";
		cin>>p[i].f.dia;
		cout<<"Mes de nacimiento: ";
		cin>>p[i].f.mes;
		cout<<"A�o de nacimiento: ";
		cin>>p[i].f.anio;
		//-------------------
		cout<<"Calle: ";
		cin>>p[i].d.calle;
		cout<<"Numero: ";
		cin>>p[i].d.numero;
		//----------------
		cout<<"Telefono: ";
		cin>>p[i].telefono;
	}
	
	//imprimimos los datos que se almacenaron en  >>struct persona p[2]<<
	cout<<"\n\nDatos de Persona"<<endl;
	for(i=0; i<2; i++){
		cout<<"\nNombre y apellido: "<<p[i].nombre<<" "<<p[i].apellido<<endl;
		cout<<"Fecha de nacimiento: "<<p[i].f.dia<<"/"<<p[i].f.mes<<"/"<<p[i].f.anio<<endl;
		cout<<"Direccion: "<<p[i].d.calle<<" "<<p[i].d.numero<<endl;
		cout<<"Telefono: "<<p[i].telefono<<endl;
	}
	
	return 0;
}

