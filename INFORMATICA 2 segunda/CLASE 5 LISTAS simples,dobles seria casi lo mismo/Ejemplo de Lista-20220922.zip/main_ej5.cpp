/*Crear una Lista de personas con nombre y apellido. Luego generar un archivo txt 
del Listado de personas.

*/
#include <iostream>
#include <fstream>
#include <string.h>
#include "LinkedList.h"

using namespace std;

struct persona
{
	string nombre;
	string apellido;
};

void mostrar(LinkedList<persona>);
void generar_archivo(LinkedList<persona>);

int main(int argc, char *argv[]) {
	
	struct persona p; 
	
	LinkedList<persona> lista_persona;

	char op=' ';
	
	do{
		
		cout<<"MENU DE OPCIONES"<<endl;
		cout<<"a. Cargar persona en LinkedLista"<<endl;
		cout<<"b. Generar archivo de personas"<<endl;
		
		cin>>op;
		switch(op){
			case 'a': 
			{
				cout<<"Ingrese nombre y apellido de persona: \n";
				cin>>p.nombre;
				cin>>p.apellido;
				lista_persona.push_back(p);
				break;
			}
		
			case 'b':
			{
				mostrar(lista_persona);
				generar_archivo(lista_persona);
				break;
			}
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
		
	}while(op=='s' || op=='S');
	
	return 0;
}

void mostrar(LinkedList<persona> lista_persona){
	struct persona p;

	LinkedList<persona> aux_lista;
	cout<<"--------------------------------------------------"<<endl;
	cout<<"LISTADO COMPLETO"<<endl;
	cout<<"NOMBRE\tAPELLIDO"<<endl;
	for(int i=0; i<(int)lista_persona.size();i++)
	{
		p=lista_persona.get(i);
		cout<<p.nombre<<"\t\t"<<p.apellido<<endl;
		aux_lista.push_back(p);
	}
	cout<<"--------------------------------------------------"<<endl;
	lista_persona=aux_lista;	
}

void generar_archivo(LinkedList<persona>lista_persona){
	ofstream ofs; 
	ofs.open("Resumen_Persona.txt");
	
	struct persona p;
	
	LinkedList<persona> aux_lista;
	ofs<<"LISTADO COMPLETO"<<endl;
	ofs<<"NOMBRE\tAPELLIDO"<<endl;
	for(int i=0; i<(int)lista_persona.size();i++)
	{
		p=lista_persona.get(i);
		ofs<<p.nombre<<"\t\t"<<p.apellido<<endl;
		aux_lista.push_back(p);

	}
	lista_persona=aux_lista;	
}
