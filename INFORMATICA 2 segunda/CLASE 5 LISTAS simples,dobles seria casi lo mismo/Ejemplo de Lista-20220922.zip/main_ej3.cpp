/* Elaborar un sistema para un hostel, en la cual posee 
una lista de habitaciones con los siguientes atributos: 
int numeroHabitacion, int cantCamas, int estadoHabitacion. 
Este ultimo puede estar ocupada (1) o desocupada (0). 
Desarrollar las siguientes funciones:
a. Mostrar las habitaciones de la lista. 
b. Reservar habitacion, es decir cambiar el estado de 
desocupado a ocupado.

Num_hab		cant_camas		estado
1			3				1
2			2				0
3			1				0

*/
#include <iostream>
#include "LinkedList.h"


using namespace std;

struct habitacion
{
	int numeroHabitacion;
	int cantCamas;
	int estadoHabitacion;
};

void mostrar(LinkedList<habitacion>);
void reservar(LinkedList<habitacion>);

int main(int argc, char *argv[]) {
	
	LinkedList<habitacion> lista;
	struct habitacion h; 
	
	h.numeroHabitacion=1;
	h.cantCamas=3;
	h.estadoHabitacion=1;
	lista.insert(0,h);
	
	h.numeroHabitacion=2;
	h.cantCamas=2;
	h.estadoHabitacion=0;
	lista.insert(1,h);
	
	h.numeroHabitacion=3;
	h.cantCamas=1;
	h.estadoHabitacion=0;
	lista.insert(2,h);
	
	mostrar(lista);
	reservar(lista);
	mostrar(lista);
	
	return 0;
}

void mostrar(LinkedList<habitacion> lista){
	struct habitacion h;
	cout<<"\nLista de habitaciones "<<endl;
	cout<<"Num. Hab.\tCant. Cam.\tEstado"<<endl;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		cout<<h.numeroHabitacion<<"\t\t"<<h.cantCamas<<"\t\t"<<h.estadoHabitacion<<endl;
	}
}
	
void reservar(LinkedList<habitacion> lista){
	struct habitacion h;
	cout<<"\nLista de habitaciones disponibles "<<endl;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		if(h.estadoHabitacion==0)
			cout<<h.numeroHabitacion<<"\t\t"<<h.cantCamas<<"\t\t"<<h.estadoHabitacion<<endl;
	}
	int num_hab;
	cout<<"\nSeleccionar un numero de habitacion: ";
	cin>>num_hab;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		if(h.numeroHabitacion==num_hab){
			h.estadoHabitacion=1;
			lista.replace(i, h);
		}
	}
}


