#include <iostream>
#include "Habitacion.h"
#include "LinkedList.h"

using namespace std;

void mostrar(LinkedList<Habitacion>);
void reservar(LinkedList<Habitacion>);

int main(int argc, char *argv[]) {
	
	Habitacion h;
	LinkedList<Habitacion> lista;
	
	h.setNumeroHabitacion(1);
	h.setCantCamas(3);
	h.setEstadoHabitacion(1);
	lista.insert(0,h);
	
	h.setNumeroHabitacion(2);
	h.setCantCamas(2);
	h.setEstadoHabitacion(0);
	lista.insert(1,h);
	
	h.setNumeroHabitacion(3);
	h.setCantCamas(1);
	h.setEstadoHabitacion(0);
	lista.insert(2,h);
	
	mostrar(lista);
	reservar(lista);
	mostrar(lista);
	
	return 0;
}

void mostrar(LinkedList<Habitacion> lista){
	Habitacion h;
	cout<<"\nLista de habitaciones "<<endl;
	cout<<"Num. Hab.\tCant. Cam.\tEstado"<<endl;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		cout<<h.getNumeroHabitacion()<<"\t\t"<<h.getCantCamas()<<"\t\t"<<h.getEstadoHabitacion()<<endl;
	}
}
	
void reservar(LinkedList<Habitacion> lista){
	Habitacion h;
	cout<<"\nLista de habitaciones disponibles "<<endl;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		if(h.getEstadoHabitacion()==0)
			cout<<h.getNumeroHabitacion()<<"\t\t"<<h.getCantCamas()<<"\t\t"<<h.getEstadoHabitacion()<<endl;
	}
	int num_hab;
	cout<<"\nSeleccionar un numero de habitacion: ";
	cin>>num_hab;
	for(int i=0; i<3;i++){
		h=lista.get(i);
		if(h.getNumeroHabitacion()==num_hab){
			h.setEstadoHabitacion(1);
			lista.replace(i, h);
		}
	}
}
		
