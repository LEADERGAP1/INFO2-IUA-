#include <string>
using namespace std;

class Habitacion {
private:
	int numeroHabitacion;
	int cantCamas;
	int estadoHabitacion;
public:
	Habitacion(); // constructor de objetos
	//funciones publicas que permiten asignar o leer los datos del objeto
	void setNumeroHabitacion(int num_hab);
	int getNumeroHabitacion();
	
	void setCantCamas(int cant_cam);
	int getCantCamas();
	
	void setEstadoHabitacion(int estado_hab);
	int getEstadoHabitacion();
};
//desarrollo de las funciones de la clase.
Habitacion::Habitacion() { //es el contructor por defecto
}
void Habitacion::setNumeroHabitacion(int num_hab) {
	numeroHabitacion = num_hab;}
int Habitacion::getNumeroHabitacion() {
	return numeroHabitacion; }

void Habitacion::setCantCamas(int cant_cam) {
	cantCamas =cant_cam;}
int Habitacion::getCantCamas() {
	return cantCamas; }

void Habitacion::setEstadoHabitacion(int estado_hab) {
	estadoHabitacion = estado_hab;}
int Habitacion::getEstadoHabitacion() {
	return estadoHabitacion; }
