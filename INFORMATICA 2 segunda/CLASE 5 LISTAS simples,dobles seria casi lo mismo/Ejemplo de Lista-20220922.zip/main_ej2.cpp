/* Crear un programa en la cual cargue una lista de 10 numeros 
aleatoriamente. Luego mostrar en pantalla el listado completo.
*/

#include <iostream>
#include "LinkedList.h"
#include <ctime>

using namespace std;

int main(int argc, char *argv[]) {
	
	LinkedList<int> l;
	srand(time(NULL));
	
	for(int i=0; i<10;i++){
		l.insert(i,rand() % 100+1);
	}
	l.print();
	

	return 0;
}

