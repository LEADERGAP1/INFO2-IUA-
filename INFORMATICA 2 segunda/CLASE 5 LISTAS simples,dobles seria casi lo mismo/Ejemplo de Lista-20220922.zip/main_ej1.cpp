#include <iostream>
#include "LinkedList.h"

using namespace std;

int main(int argc, char *argv[]) {
    LinkedList<float> l;
    // 7 5 30 4
    // 0 1 2  3

    l.insert(0, 5);
	l.insert(1, 4);
    l.insert(1, 30.1);
    l.insert(0, 7);

	cout<<"Lista: "<<endl;
	for(int i=0; i<l.size();i++){
		cout<<l.get(i)<<"\t";
	}
	


    return 0;
}
