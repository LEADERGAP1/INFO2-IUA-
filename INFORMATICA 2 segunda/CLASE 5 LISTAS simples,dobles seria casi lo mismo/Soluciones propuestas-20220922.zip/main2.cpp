/* Crear una lista con 10 letras y luego contar la cantidad
de vocales y consonantes. Luego mostrar el listado completo y 
la cantidad de vocales y consonantes.
*/
#include <iostream>
#include "LinkedList.h"
#include <ctime>
using namespace std;

int main(int argc, char *argv[]) {
	
	
	LinkedList<char> lista;
	srand(time(NULL));
	char letra=' ';
	int cant_vocal=0, cant_consonante=0;
	
	for(int i=0; i<10;i++){
		letra = (char)(rand() % 25 + 65);
		lista.insert(i,(char)letra);
	}
	
	cout<<"Lista: ";
	for(int i=0; i<10;i++){
		cout<<lista.get(i)<<" - ";
	}
	
	
	for(int i=0; i<10;i++){
		if((lista.get(i)=='A')||(lista.get(i)=='E')||(lista.get(i)=='I')||(lista.get(i)=='O')||(lista.get(i)=='U'))
			cant_vocal++;
		else
			cant_consonante++;
	}
	cout<<"\n\nVocales: "<<cant_vocal<<endl;
	cout<<"\nConsonantes: "<<cant_consonante<<endl;
	

	
	return 0;
}

