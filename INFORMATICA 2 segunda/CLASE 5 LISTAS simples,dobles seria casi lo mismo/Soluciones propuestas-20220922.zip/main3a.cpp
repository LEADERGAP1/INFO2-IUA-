/* Elaborar un sistema de stock, en la cual posee 
una lista de productos con los siguientes atributos: 
codigo, nombre, cantidad, precio lista
Desarrollar las siguientes funciones:
a. Mostrar el stock. (lista de productos)
b. Descontar stock.
c. Reponer stock.

*/
#include <iostream>
#include "LinkedList.h"

using namespace std;

struct Producto{
	int codigo;
	string nombre;
	int cantidad;
	float precio;
};

void mostrar(LinkedList<Producto>);
void descontar(LinkedList<Producto>);
void reponer(LinkedList<Producto>);

int main(int argc, char *argv[]) {
	
	LinkedList <Producto> lista;
	struct Producto p;
	
	p.codigo=1;
	p.nombre="Yerba";
	p.cantidad=10;
	p.precio=50;
	lista.push_back(p);
	
	p.codigo=2;
	p.nombre="Azucar";
	p.cantidad=15;
	p.precio=30.5;
	lista.push_back(p);
	
	p.codigo=3;
	p.nombre="Harina";
	p.cantidad=3;
	p.precio=35;
	lista.push_back(p);
	
	char op = ' ';
	do{
		cout<<"********************* MENU DE OPCIONES *******************"<<endl;
		cout<<"a. Mostrar stock."<<endl;
		cout<<"b. Descontar stock."<<endl;
		cout<<"c. Reponer stock."<<endl;
		cout<<"\nOpcion: ";
		cin>>op;
		switch(op){
		case 'a': 
		case 'A': 
			mostrar(lista);
			break;
		case 'b': 
		case 'B': 
			descontar(lista);
			break;
		case 'c': 
		case 'C': 
			reponer(lista);
			break;
		default: 
			cout<<"Ingrese una opcion valida. ";
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	}while(op=='s' || op=='S');
	
	return 0;
}


void mostrar(LinkedList <Producto> lista){
	struct Producto p;
	cout<<"Cod\tNom\tCant\tPre"<<endl;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		cout<<p.codigo<<"\t"<<p.nombre<<"\t"<<p.cantidad<<"\t"<<p.precio<<endl;
	}
}
	
void descontar(LinkedList <Producto> lista){
	struct Producto p;
	int cod=0,desc=0;
	cout<<"Ingrese el codigo del producto a descontar: ";
	cin>>cod;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		if(p.codigo==cod){
			cout<<"Hay "<<p.cantidad<<" productos de "<<p.nombre<<". Ingrese la cantidad a descontar: ";
			cin>>desc;
			while(desc>p.cantidad){
				cout<<"Ingrese una cantidad menor o igual a "<<p.cantidad<<": ";
				cin>>desc;
			}
			p.cantidad=p.cantidad-desc;		
			lista.replace(i,p);
		}
	}
}
		
void reponer (LinkedList <Producto> lista){
	struct Producto p;
	int cod=0,rep=0;
	cout<<"Ingrese el codigo del producto a reponer: ";
	cin>>cod;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		if(p.codigo==cod){
			cout<<"Hay "<<p.cantidad<<" productos de "<<p.nombre<<". Ingrese la cantidad a reponer: ";
			cin>>rep;
			while(rep<=0){
				cout<<"Ingrese una cantidad mayor a cero: ";
				cin>>rep;
			}
			p.cantidad=p.cantidad+rep;		
			lista.replace(i,p);
		}
	}
}
