/* Elaborar un sistema de stock, en la cual posee 
una lista de productos con los siguientes atributos: 
codigo, nombre, cantidad, precio lista
Desarrollar las siguientes funciones:
a. Mostrar el stock. (lista de productos)
b. Descontar stock.
c. Reponer stock.

*/

#include <iostream>
#include "Producto.h"
#include "LinkedList.h"

using namespace std;

void mostrar(LinkedList<Producto>);
void descontar(LinkedList<Producto>);
void reponer(LinkedList<Producto>);

int main(int argc, char *argv[]) {
	
	Producto p;
	LinkedList<Producto> lista;
	
	p.setCodigo(1);
	p.setNombre("Yerba");
	p.setCantidad(10);
	p.setPrecio(50);
	lista.push_back(p);
	
	p.setCodigo(2);
	p.setNombre("Azucar");
	p.setCantidad(15);
	p.setPrecio(30.5);
	lista.push_back(p);
	
	p.setCodigo(3);
	p.setNombre("Harina");
	p.setCantidad(3);
	p.setPrecio(35);
	lista.push_back(p);
	
	char op = ' ';
	do{
		cout<<"********************* MENU DE OPCIONES *******************"<<endl;
		cout<<"a. Mostrar stock."<<endl;
		cout<<"b. Descontar stock."<<endl;
		cout<<"c. Reponer stock."<<endl;
		cout<<"\nOpcion: ";
		cin>>op;
		switch(op){
		case 'a': 
		case 'A': 
			mostrar(lista);
			break;
		case 'b': 
		case 'B': 
			descontar(lista);
			break;
		case 'c': 
		case 'C': 
			reponer(lista);
			break;
		default: 
			cout<<"Ingrese una opcion valida. ";
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	}while(op=='s' || op=='S');
	
	return 0;
}


void mostrar(LinkedList <Producto> lista){
	Producto p;
	cout<<"Cod\tNom\tCant\tPre"<<endl;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		cout<<p.getCodigo()<<"\t"<<p.getNombre()<<"\t"<<p.getCantidad()<<"\t"<<p.getPrecio()<<endl;
	}
}
	
void descontar(LinkedList <Producto> lista){
	Producto p;
	int cod=0,desc=0;
	cout<<"Ingrese el codigo del producto a descontar: ";
	cin>>cod;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a descontar: ";
			cin>>desc;
			while(desc>p.getCantidad()){
				cout<<"Ingrese una cantidad menor o igual a "<<p.getCantidad()<<": ";
				cin>>desc;
			}
			p.setCantidad(p.getCantidad()-desc);		
			lista.replace(i,p);
		}
	}
}
		
void reponer (LinkedList <Producto> lista){
	Producto p;
	int cod=0,rep=0;
	cout<<"Ingrese el codigo del producto a reponer: ";
	cin>>cod;
	for(int i=0; i<(int)lista.size(); i++){
		p=lista.get(i);
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a reponer: ";
			cin>>rep;
			while(rep<=0){
				cout<<"Ingrese una cantidad mayor a cero: ";
				cin>>rep;
			}
			p.setCantidad(p.getCantidad()+rep);
			lista.replace(i,p);
		}
	}
}
