#include <iostream>
#include <string>

using namespace std;

class Producto{
private:
	
	int codigo;
	string nombre;
	int cantidad;
	float precio;
	
public:
	Producto();
	
	void setCodigo(int cod);
	int getCodigo();
	
	void setNombre(string nom);
	string getNombre();
	
	void setCantidad(int cant);
	int getCantidad();
	
	void setPrecio(float pre);
	float getPrecio();
};

Producto::Producto() { //es el contructor por defecto
}

void Producto::setCodigo(int cod) {
	codigo = cod;}
int Producto::getCodigo() {
	return codigo; }

void Producto::setNombre(string nom) {
	nombre = nom;}
string Producto::getNombre() {
	return nombre; }

void Producto::setCantidad(int cant) {
	cantidad = cant;}
int Producto::getCantidad() {
	return cantidad; }

void Producto::setPrecio(float pre) {
	precio = pre;}
float Producto::getPrecio() {
	return precio; }

