#include <iostream>
#include <list>
#include <cstdlib>
using namespace std;


int main(int argc, char *argv[]) {

	list <int> l;
	
	for (int i=0; i < 10; i++)
	{
		l.push_back(rand()%100);
	}
	
	list<int>::iterator it = l.begin();
	
	cout << "Orden original" << endl;
	while( it != l.end() )
	{
		cout << *it++ << endl;
	}
	
	l.sort();
	
	it = l.begin();
	cout << "Orden ascendente" << endl;
	
	while( it != l.end() )
	{
		cout << *it++ << endl;
	}

	return 0;
}

