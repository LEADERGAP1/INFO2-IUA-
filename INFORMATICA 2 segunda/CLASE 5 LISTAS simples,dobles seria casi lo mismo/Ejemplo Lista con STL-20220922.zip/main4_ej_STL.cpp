#include <iostream>
#include <list>
#include <queue>

using namespace std;

struct Request {
    string owner;
    string petToSit;
    string fromDate;
    string toDate;
    string city;
    string carer;
};

void menu(int *);
void registerRequest(list<Request> *);
void assignCarer(list<Request> *);
void showRequests(list<Request> *);
void showPetsWithUnassignedCarers(list<Request> *);

int main() {
    Request r1, r2;
    r1.owner = "Sofia";
    r2.owner = "Laura";
    r1.petToSit = "3 perros";
    r2.petToSit = "2 gatos";
    r1.fromDate = "20/12/2020";
    r2.fromDate = "02/11/2020";
    r1.toDate = "05/01/2020";
    r2.toDate = "10/11/2020";
    r1.city = "Cordoba";
    r2.city = "Alta Gracia";
    r1.carer = "Belen";
    r2.carer = "0";

    list<Request> listRequests;
    listRequests.push_back(r1);
    listRequests.push_back(r2);
    bool inLoop = true;
    cout << "Bienvenido al sistema automatizado de cuidador de animales!" << endl;
    while (inLoop) {
        int choice;
        menu(&choice);
        if (choice == 1) {
            registerRequest(&listRequests);
        } else if (choice == 2) {
            assignCarer(&listRequests);
        } else if (choice == 3) {
            showRequests(&listRequests);
        } else if (choice == 4) {
            showPetsWithUnassignedCarers(&listRequests);
        } else if (choice == 5) {
            inLoop = false;
        } else {
            cout << "Elija una opcion valida." << endl;
        }
    }
    cout << "Adios!" << endl;
    return 0;
}

void menu(int *choice) {
    cout << "Que desea hacer?" << endl;
    cout << " 1) Registrar un pedido." << endl;
    cout << " 2) Asignar un cuidador." << endl;
    cout << " 3) Mostrar listado de pedidos." << endl;
    cout << " 4) Mostrar mascotas sin un cuidador asignado." << endl;
    cout << " 5) Terminar programa." << endl;
    cout << "> ";
    cin >> *choice;
    cout << endl;
}

void registerRequest(list<Request> *listRequests) {
    Request req;
    cout << "Duenio/a: ";
    cin >> req.owner;
    cout << " * A cuidar: ";
    cin >> req.petToSit;
    cout << " * Desde el: ";
    cin >> req.fromDate;
    cout << " * Hasta el: ";
    cin >> req.toDate;
    cout << " * En la ciudad: ";
    cin >> req.city;
    cout << " * Cuidador: ";
    cin >> req.carer;
    cout << endl;
    listRequests->push_back(req);
}

void assignCarer(list<Request> *listRequests) {
    bool aux = false;
    list<Request>::iterator itReq;
    for (itReq = listRequests->begin(); listRequests->end() != itReq; itReq++) {
        if (itReq->carer == "0") {
            aux = true;
            cout << "Duenio/a: " << itReq->owner << endl;
            cout << " * A cuidar: " << itReq->petToSit << endl;
            cout << " * Desde el: " << itReq->fromDate << endl;
            cout << " * Hasta el: " << itReq->toDate << endl;
            cout << " * En la ciudad: " << itReq->city << endl;
            cout << " * Cuidador: " << itReq->carer << endl;
            cout << endl;
        }
    }
    string name;
    if (aux) {
        bool found = true;
        do {
            if (!found)
                cout << "Duenio no encontrado." << endl;
            found = false;
            cout << "Ingrese el nombre del duenio al que desea asignar un cuidador: ";
            cin >> name;

            list<Request>::iterator itReq;
            for (itReq = listRequests->begin(); listRequests->end() != itReq; itReq++) {
                if (itReq->owner == name) {
                    if (itReq->carer == "0") {
                        string carerName;
                        found = true;
                        cout << "Ingrese nombre del cuidador/ra: ";
                        cin >> itReq->carer;
                        cout << endl;
                    } else {
                        cout << "Ese pedido ya tiene un cuidador asignado" << endl;
                    }
                }
            }
        } while (!found);
    } else {
        cout << "No hay pedidos sin cuidador asignado" << endl;
    }
}

void showRequests(list<Request> *listRequests) {
    list<Request>::iterator itReq;
    for (itReq = listRequests->begin(); listRequests->end() != itReq; itReq++) {
        cout << "Duenio/a: " << itReq->owner << endl;
        cout << " * A cuidar: " << itReq->petToSit << endl;
        cout << " * Desde el: " << itReq->fromDate << endl;
        cout << " * Hasta el: " << itReq->toDate << endl;
        cout << " * En la ciudad: " << itReq->city << endl;
        cout << " * Cuidador: " << itReq->carer << endl;
        cout << endl;
    }
}

void showPetsWithUnassignedCarers(list<Request> *listRequests) {
    queue<Request> queueRequests;
    list<Request>::iterator itReq;
    for (itReq = listRequests->begin(); listRequests->end() != itReq; itReq++) {
        if (itReq->carer == "0") {
            Request r;
            r.owner = itReq->owner;
            r.petToSit = itReq->petToSit;
            r.fromDate = itReq->fromDate;
            r.toDate = itReq->toDate;
            r.city = itReq->city;
            r.carer = itReq->carer;
            queueRequests.push(r);
        }
    }
    int size = queueRequests.size();
    for (int i = 0; i < size; i++) {
        Request r = queueRequests.front();
        queueRequests.pop();
        cout << "Duenio/a: " << r.owner << endl;
        cout << " * A cuidar: " << r.petToSit << endl;
        cout << " * Desde el: " << r.fromDate << endl;
        cout << " * Hasta el: " << r.toDate << endl;
        cout << " * En la ciudad: " << r.city << endl;
        cout << " * Cuidador: " << r.carer << endl;
        cout << endl;
    }
}
