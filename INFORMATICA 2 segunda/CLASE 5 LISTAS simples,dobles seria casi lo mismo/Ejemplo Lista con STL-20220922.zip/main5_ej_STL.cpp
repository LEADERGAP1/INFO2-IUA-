/*Crear una lista de personas con nombre y apellido. Luego generar un archivo txt 
del listado de personas.

*/
#include <iostream>
#include <fstream>
#include <list>
#include <string.h>

using namespace std;

struct persona
{
	string nombre;
	string apellido;
};

void mostrar_lista_persona(list<persona>);
void generar_archivo_lista_persona(list<persona>);

int main(int argc, char *argv[]) {
	
	struct persona p; 
	
	list<persona> lista_persona;
	list<persona> aux_persona;
	
	char op=' ';
	
	do{
		
		cout<<"MENU DE OPCIONES"<<endl;
		cout<<"a. Cargar persona en lista"<<endl;
		cout<<"b. Generar archivo de personas"<<endl;
		
		cin>>op;
		switch(op){
			case 'a': 
			{
				cout<<"Ingrese nombre y apellido de persona: \n";
				cin>>p.nombre;
				cin>>p.apellido;
				lista_persona.push_front(p);
				break;
			}
		
			case 'b':
			{
				mostrar_lista_persona(lista_persona);
				generar_archivo_lista_persona(lista_persona);
				break;
			}
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
		
	}while(op=='s' || op=='S');
	
	return 0;
}

void mostrar_lista_persona(list<persona> lista_persona){
	struct persona p;
	list<persona> aux_lista;
	cout<<"--------------------------------------------------"<<endl;
	cout<<"LISTADO COMPLETO"<<endl;
	cout<<"NOMBRE\tAPELLIDO"<<endl;
	while(!lista_persona.empty())
	{
		p=lista_persona.front();
		cout<<p.nombre<<"\t\t"<<p.apellido<<endl;
		aux_lista.push_back(p);
		lista_persona.pop_front();
	}
	cout<<"--------------------------------------------------"<<endl;
	lista_persona=aux_lista;	
}

void generar_archivo_lista_persona(list<persona> lista_persona){
	ofstream ofs; 
	ofs.open("Resumen_Persona.txt");
	
	struct persona p;
	list<persona> aux_lista;
	ofs<<"LISTADO COMPLETO"<<endl;
	ofs<<"NOMBRE\tAPELLIDO"<<endl;
	while(!lista_persona.empty())
	{
		p=lista_persona.front();
		ofs<<p.nombre<<"\t\t"<<p.apellido<<endl;
		aux_lista.push_back(p);
		lista_persona.pop_front();
	}
	lista_persona=aux_lista;	
}
