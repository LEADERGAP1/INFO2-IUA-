#include <iostream>
#include <list>

using namespace std;

void muestra(const list<int> &l)
{
	list<int>::const_iterator it = l.begin();
	while( it != l.end()) {
		cout << *it << endl;
		++it;
	}
}

int main()
{
	list<int> l;
	
	l.insert( l.end(), 1 );       // { 1 }
	l.insert( l.end(), 2 );       // { 1, 2 }
	l.insert( l.begin(), 3 );     // { 3, 1, 2 }
	
	//
	
	l.push_back(4);
	l.push_back(5);
	l.push_back(6);
	
	muestra(l);
 }
