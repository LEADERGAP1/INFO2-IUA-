#include <iostream>
#include <list>

using namespace std;

int main(int argc, char *argv[])
{
	list<double> lalista;
	double num, suma=0;
	
	cout << "Suma de Numeros" << endl;
	
	do
	{
		cout << "Ingrese un numero, 0 para salir: ";
		cin  >> num;
		if (num != 0) 
			lalista.push_back(num);
	}
	while (num != 0);
	
	cout << "----------" << endl;
	
	while( !lalista.empty() )
	{
		num = lalista.front();
		cout << num << endl;
		suma += num;
		lalista.pop_front();
	}
	cout << "----------" << endl;
	
	cout << suma << endl;
	
	return 0;
}
