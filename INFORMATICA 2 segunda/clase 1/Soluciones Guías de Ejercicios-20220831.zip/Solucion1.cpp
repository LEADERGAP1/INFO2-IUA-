/*Escribir un programa que declare e inicialice una variable del tipo 
float n=5/2. Luego imprima el resultado de la divisi�n, la misma deber�a ser 2,5.
*/

#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	
	float n=(float)5/2;
	printf("%f", n);
	return 0;
}

