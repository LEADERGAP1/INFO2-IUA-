/* Crear un programa en la cual el usuario cargue una serie de valores en una 
cola. Luego se pide:
- calcular el promedio de los valores
- mostrar en pantalla el los elementos de la cola
*/

#include <iostream>
#include <queue>

using namespace std;

double calcularPromedioCola(queue<double>);
void mostrarCola(queue<double>);

int main(int argc, char *argv[]) {

	queue<double> lacola; //creamos una cola
	double num=0;
	
	//encolamos valores a la cola con la funcion push()
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lacola.push(num);
	}
	while (num != 0);
	
	cout << "El promedio de los elementos de la cola es: " << calcularPromedioCola(lacola) << endl;
	mostrarCola(lacola);
	return 0;
}

double calcularPromedioCola(queue<double> lacola){
	queue<double> aux_cola; //creamos una cola auxiliar para no perder los valores
	double suma=0, prom=0;
	while(!lacola.empty())
	{
		suma=suma+lacola.front();
		aux_cola.push(lacola.front()); //para no perder los valores los pasamos a una cola auxiliar
		lacola.pop(); //borra el elemento de la cola original
	}
	lacola=aux_cola;//pasa los valores de la cola auxiliar a la cola original
	prom=suma/lacola.size();
	return prom;
}


void mostrarCola(queue<double> lacola){
	queue<double> aux_cola; //creamos una cola auxiliar para no perder los valores
	cout << "\nLos elementos de la cola son: ";
	while(!lacola.empty())
	{
		cout << lacola.front() <<" - ";
		aux_cola.push(lacola.front()); //para no perder los valores los pasamos a una cola auxiliar
		lacola.pop(); //borra el elemento de la cola original
	}
	lacola=aux_cola;//pasa los valores de la cola auxiliar a la cola original
}
