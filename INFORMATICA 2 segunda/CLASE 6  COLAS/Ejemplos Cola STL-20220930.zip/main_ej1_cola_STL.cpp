#include <iostream>
#include <queue> //incluimos la libreria STL

using namespace std;

int main(int argc, char *argv[]) {
	
	queue<double> lacola; 	//creamos una cola con un tipo
	double num=0;
	
	//encolamos valores a la cola con la funcion push()
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lacola.push(num);
	}
	while (num != 0);
	
	cout << "\nCantidad de elementos de la cola: "<<lacola.size()<<endl;
	
	cout << "\nEl primer elemento de la cola es: "<<lacola.front()<<endl;	
	
	cout << "\nEl ultimo elemento de la cola es: "<<lacola.back()<<endl;
	
	cout << "\nLos elementos de la cola son: ";
	//recorremos la cola hasta que este vacia, con la funcion empty()
	while(!lacola.empty())
	{
		num = lacola.front(); //trae el primer elemento de la cola
		cout << num <<" - ";
		lacola.pop(); //borra el elemento de la cola
	}
	return 0;
}
