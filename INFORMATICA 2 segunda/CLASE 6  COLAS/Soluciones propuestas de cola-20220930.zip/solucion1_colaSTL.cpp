/* Crear un programa en la cual el usuario cargue una serie de valores en una 
cola. Luego se pide:
- mostrar en pantalla el los elementos de la cola
- borrar un elemento de la cola
- agregar un elemento que no este en la cola
*/

#include <iostream>
#include <queue>

using namespace std;

void mostrarCola(queue<double>);
queue<double> borrarElemento(queue<double>);
queue<double> agregarElemento(queue<double>);
bool buscarElemento(queue<double>, double);

int main(int argc, char *argv[]) {
	
	queue<double> lacola; 
	double num=0;
	
	cout << "Ingrese los numeros [fin=0]"<<endl;
	do
	{
		cin  >> num;
		if (num != 0) 
			lacola.push(num);
	}
	while (num != 0);
	
	mostrarCola(lacola);
	lacola=borrarElemento(lacola);
	mostrarCola(lacola);
	lacola=agregarElemento(lacola);
	mostrarCola(lacola);
	return 0;
}


void mostrarCola(queue<double> lacola){
	queue<double> aux_cola; 
	cout << "\nLos elementos de la cola son:\t";
	while(!lacola.empty())
	{
		cout << lacola.front() <<" - ";
		aux_cola.push(lacola.front()); 
		lacola.pop();
	}
	lacola=aux_cola;
}
	
queue<double> borrarElemento(queue<double> lacola){
	double num_borrar=0;
	queue<double> aux_cola;
	cout << "\nIngrese el elemento a borrar: ";
	cin>>num_borrar;
	while(!lacola.empty())
	{
		if(lacola.front()!=num_borrar){
			aux_cola.push(lacola.front()); 
		}
		lacola.pop();
	}
	return aux_cola;
}

bool buscarElemento(queue<double> lacola, double num_buscar){
	queue<double> aux_cola;
	bool bandera_buscado=false;
	while(!lacola.empty())
	{
		if(lacola.front()==num_buscar){
			bandera_buscado=true;
		}
		aux_cola.push(lacola.front()); 
		lacola.pop();
	}
	lacola=aux_cola;	
	return bandera_buscado;
}

queue<double> agregarElemento(queue<double> lacola){
	double num_agregar=0;
	queue<double> aux_cola;
	bool bandera=false;
	do{
		cout << "\nIngrese el elemento a agregar: ";
		cin>>num_agregar;
		bandera=buscarElemento(lacola, num_agregar);
		if(bandera==false){
			lacola.push(num_agregar);
		}else{
			cout << "\nExiste este valor.";
		}
	}while(bandera==true);
		
	return lacola;
}
		
