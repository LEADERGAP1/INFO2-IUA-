/* Elaborar un sistema de stock, en la cual posee 
una cola de productos con los siguientes atributos: 
codigo, nombre, cantidad, precio lista
Desarrollar las siguientes funciones:
a. Mostrar el stock. (cola de productos)
b. Descontar stock.
c. Reponer stock.

*/

#include <iostream>
#include "Producto.h"
#include <queue>

using namespace std;

void mostrar(queue<Producto>);
queue <Producto> descontar(queue<Producto>);
queue <Producto> reponer(queue<Producto>);

int main(int argc, char *argv[]) {
	
	Producto p;
	queue<Producto> colaProducto;
	
	p.setCodigo(1);
	p.setNombre("Yerba");
	p.setCantidad(10);
	p.setPrecio(50);
	colaProducto.push(p);
	
	p.setCodigo(2);
	p.setNombre("Azucar");
	p.setCantidad(15);
	p.setPrecio(30.5);
	colaProducto.push(p);
	
	p.setCodigo(3);
	p.setNombre("Harina");
	p.setCantidad(3);
	p.setPrecio(35);
	colaProducto.push(p);
	
	char op = ' ';
	do{
		cout<<"********************* MENU DE OPCIONES *******************"<<endl;
		cout<<"a. Mostrar stock."<<endl;
		cout<<"b. Descontar stock."<<endl;
		cout<<"c. Reponer stock."<<endl;
		cout<<"\nOpcion: ";
		cin>>op;
		switch(op){
		case 'a': 
		case 'A': 
			mostrar(colaProducto);
			break;
		case 'b': 
		case 'B': 
			colaProducto=descontar(colaProducto);
			break;
		case 'c': 
		case 'C': 
			colaProducto=reponer(colaProducto);
			break;
		default: 
			cout<<"Ingrese una opcion valida. ";
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	}while(op=='s' || op=='S');
	
	return 0;
}


void mostrar(queue <Producto> colaProducto){
	Producto p;
	queue<Producto> aux_cola; 
	cout<<"Cod\tNom\tCant\tPre"<<endl;
	while(!colaProducto.empty())
	{
		p=colaProducto.front();
		cout<<p.getCodigo()<<"\t"<<p.getNombre()<<"\t"<<p.getCantidad()<<"\t"<<p.getPrecio()<<endl;
		aux_cola.push(colaProducto.front()); 
		colaProducto.pop();
	}
	colaProducto=aux_cola;	
}
	
queue <Producto> descontar(queue <Producto> colaProducto){
	Producto p;
	queue<Producto> aux_cola; 
	int cod=0,desc=0;
	cout<<"Ingrese el codigo del producto a descontar: ";
	cin>>cod;
	while(!colaProducto.empty())
	{
		p=colaProducto.front();
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a descontar: ";
			cin>>desc;
			while(desc>p.getCantidad()){
				cout<<"Ingrese una cantidad menor o igual a "<<p.getCantidad()<<": ";
				cin>>desc;
			}
			p.setCantidad(p.getCantidad()-desc);
		}
		aux_cola.push(p); 
		colaProducto.pop();
	}
	return aux_cola;
}
		
queue <Producto> reponer (queue <Producto> colaProducto){
	Producto p;
	queue<Producto> aux_cola; 
	int cod=0,rep=0;
	cout<<"Ingrese el codigo del producto a reponer: ";
	cin>>cod;
	
	while(!colaProducto.empty())
	{
		p=colaProducto.front();
		if(p.getCodigo()==cod){
			cout<<"Hay "<<p.getCantidad()<<" productos de "<<p.getNombre()<<". Ingrese la cantidad a reponer: ";
			cin>>rep;
			while(rep<=0){
				cout<<"Ingrese una cantidad mayor a cero: ";
				cin>>rep;
			}
			p.setCantidad(p.getCantidad()+rep);
		}
		aux_cola.push(p); 
		colaProducto.pop();
	}
	return aux_cola;
}
