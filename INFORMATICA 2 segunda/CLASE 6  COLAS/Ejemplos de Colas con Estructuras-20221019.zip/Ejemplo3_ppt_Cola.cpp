#include <iostream>
using namespace std;

struct persona{
	string nombre;
	int edad;
};

struct node{
	struct persona p;
	struct node *link;
};

int menu();
void push(struct node **, struct node **, struct persona);
void pop(struct node **, struct node **);
void print(struct node *);

int main(int argc, char *argv[]) {
	
	struct node *front = NULL;
	struct node *back = NULL;
	int op=0;
	
	struct persona p;
	
	do{
		op=menu();
		switch(op){
		case 1: 
			cout<<"Ingrese el nombre y la edad de la persona a insertar\n";
			cin>>p.nombre>>p.edad;
			push(&front, &back, p);
			break;
		case 2: 
			pop(&front, &back);
			break;
		case 3: 
			print(front);
			break;
		}
	} while(op!=4);
	return 0;
}

int menu(void){
	int op=0;
	do{
		cout<<"\n1.- Agregar una persona de la cola\n";
		cout<<"2.- Borrar una persona de la cola\n";
		cout<<"3.- Imprimir cola de personas\n";
		cout<<"4.- Salir\n";
		cin>>op;
	}while((op<1)||(op>4));
	return op;
}

void push(struct node **front, struct node **back, struct persona p){
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	if(temp==NULL){
		cout<<"No hay suficiente memoria";
		exit(0);
	}
	temp->p=p;
	temp->link=NULL;
	if(*back==NULL){ //Insercion del primer nodo
		*back=temp;
		*front=*back;
	}else{ //Insercion del resto de los nodos
		(*back)->link =temp;
		*back=temp;
	}
}

void pop(struct node **front, struct node **back){
	struct node *temp;
	if((*front==*back)&&(*back==NULL)){
		cout<<"Vacia\n";
		exit(0);
	}
	temp=*front;
	*front = (*front)->link;
	if(*back==temp){
		*back=(*back)->link;
	}
	free(temp);
}

void print(struct node *front){
	struct node *temp = NULL;
	//Impresion de toda la FIFO
	temp=front;
	while(temp!=NULL){
		//printf("%c\t%d\n", temp->p.nombre, temp->p.edad);
		cout<<temp->p.nombre<<"\t"<<temp->p.edad<<"\n";
		temp=temp->link;
	}
	cout<<"\n";
}
